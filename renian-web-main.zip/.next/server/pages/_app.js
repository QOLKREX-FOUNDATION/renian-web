(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4467:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ Index)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4338);
/* harmony import */ var _components_atoms_Preloader_Preloader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1312);
/* harmony import */ var _contexts_Preloader_PreloaderContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(707);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_4__, _components__WEBPACK_IMPORTED_MODULE_5__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_4__, _components__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Index = ({ children  })=>{
    const { preloader  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_Preloader_PreloaderContext__WEBPACK_IMPORTED_MODULE_7__/* .PreloaderContext */ .j);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_5__/* .Header */ .h4, {}),
                    children,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_5__/* .WhatsappWidget */ .Ay, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_5__/* .Footer */ .$_, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {}),
            preloader && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_atoms_Preloader_Preloader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ src_Providers)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/contexts/Preloader/PreloaderContext.jsx
var PreloaderContext = __webpack_require__(707);
;// CONCATENATED MODULE: ./src/contexts/Preloader/PreloaderProvider.jsx



const INIT_STATE = {
    preloader: false
};
const PreloaderProvider = ({ children  })=>{
    const { 0: preloader , 1: setPreloader  } = (0,external_react_.useState)(INIT_STATE);
    const handlePreloader = (value)=>{
        setPreloader({
            preloader: value
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(PreloaderContext/* PreloaderContext.Provider */.j.Provider, {
        value: {
            ...preloader,
            handlePreloader
        },
        children: children
    });
};

// EXTERNAL MODULE: external "web3"
var external_web3_ = __webpack_require__(8519);
var external_web3_default = /*#__PURE__*/__webpack_require__.n(external_web3_);
// EXTERNAL MODULE: ./src/contexts/Web3/Web3Context.jsx
var Web3Context = __webpack_require__(5677);
;// CONCATENATED MODULE: ./src/contexts/Web3/Web3Reducer.jsx
const Web3Reducer = (state, action)=>{
    switch(action.type){
        case "provider":
            return {
                ...state,
                wallet: action.payload.web3,
                provider: action.payload.provider,
                providerString: action.payload.providerString
            };
        case "account":
            return {
                ...state,
                account: action.payload
            };
        case "chainId":
            return {
                ...state,
                chainId: action.payload
            };
        case "token":
            return {
                ...state,
                authToken: action.payload.authToken,
                authTimeOut: action.payload.authTimeOut
            };
        default:
            return state;
    }
};

// EXTERNAL MODULE: ./src/config/index.js + 5 modules
var config = __webpack_require__(9085);
;// CONCATENATED MODULE: ./src/contexts/Web3/Web3Provider.jsx






const INIT = {
    account: "",
    network: new (external_web3_default())(new (external_web3_default()).providers.HttpProvider(config/* WEB3_NETWORK */.nH)),
    networkWar: new (external_web3_default())(new (external_web3_default()).providers.HttpProvider(config/* WEB3_NETWORKWAR */.iw)),
    wallet: null,
    provider: null,
    providerString: "",
    chainId: null,
    authToken: "",
    authTimeOut: ""
};
const Web3Provider = ({ children  })=>{
    const { 0: state , 1: dispatch  } = (0,external_react_.useReducer)(Web3Reducer, INIT);
    const handleWeb3 = (0,external_react_.useCallback)((provider, providerString)=>{
        dispatch({
            type: "provider",
            payload: {
                web3: provider === null ? null : new (external_web3_default())(provider),
                provider,
                providerString
            }
        });
    }, []);
    const handleAccount = (0,external_react_.useCallback)((account)=>{
        dispatch({
            type: "account",
            payload: account
        });
    }, []);
    const handleChainId = (0,external_react_.useCallback)((chainId)=>{
        dispatch({
            type: "chainId",
            payload: chainId
        });
    }, []);
    const handleToken = (0,external_react_.useCallback)((authToken, authTimeOut)=>{
        dispatch({
            type: "token",
            payload: {
                authToken,
                authTimeOut
            }
        });
    }, []);
    (0,external_react_.useEffect)(()=>{
        const getAccounts = async ()=>await state.wallet?.eth.getAccounts();
        if (state.wallet !== null) {
            getAccounts().then((accounts)=>handleAccount(accounts[0]));
        }
    }, [
        state.wallet,
        handleAccount
    ]);
    (0,external_react_.useEffect)(()=>{
        const getChainId = async ()=>await state.wallet?.eth.getChainId();
        if (state.wallet !== null) {
            getChainId().then((chainId)=>{
                handleChainId(`0x${Number(chainId).toString(16)}`);
            });
        }
    }, [
        state.wallet,
        handleChainId
    ]);
    const web3 = (0,external_react_.useMemo)(()=>state, [
        state
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Web3Context/* Web3Context.Provider */.S.Provider, {
        value: {
            web3,
            handleWeb3,
            handleAccount,
            handleChainId,
            handleToken
        },
        children: children
    });
};

;// CONCATENATED MODULE: ./src/Providers.jsx



const Providers = ({ children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Web3Provider, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(PreloaderProvider, {
            children: children
        })
    });
};
/* harmony default export */ const src_Providers = (Providers);


/***/ }),

/***/ 2654:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Providers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1915);
/* harmony import */ var _Index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4467);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Index__WEBPACK_IMPORTED_MODULE_2__]);
_Index__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Providers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Index__WEBPACK_IMPORTED_MODULE_2__/* .Index */ .g, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 2433:
/***/ ((module) => {

"use strict";
module.exports = require("@react-google-maps/api");

/***/ }),

/***/ 4137:
/***/ ((module) => {

"use strict";
module.exports = require("@walletconnect/web3-provider");

/***/ }),

/***/ 3623:
/***/ ((module) => {

"use strict";
module.exports = require("hamburger-react");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 609:
/***/ ((module) => {

"use strict";
module.exports = require("react-countup");

/***/ }),

/***/ 1189:
/***/ ((module) => {

"use strict";
module.exports = require("react-lottie");

/***/ }),

/***/ 782:
/***/ ((module) => {

"use strict";
module.exports = require("react-player/lazy");

/***/ }),

/***/ 4931:
/***/ ((module) => {

"use strict";
module.exports = require("react-reveal");

/***/ }),

/***/ 8223:
/***/ ((module) => {

"use strict";
module.exports = require("react-reveal/Bounce");

/***/ }),

/***/ 1665:
/***/ ((module) => {

"use strict";
module.exports = require("react-reveal/Fade");

/***/ }),

/***/ 1952:
/***/ ((module) => {

"use strict";
module.exports = require("react-reveal/Zoom");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 1929:
/***/ ((module) => {

"use strict";
module.exports = require("react-select");

/***/ }),

/***/ 2162:
/***/ ((module) => {

"use strict";
module.exports = require("react-tippy");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 8519:
/***/ ((module) => {

"use strict";
module.exports = require("web3");

/***/ }),

/***/ 6881:
/***/ ((module) => {

"use strict";
module.exports = import("@react-hook/hover");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

"use strict";
module.exports = import("html-react-parser");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,402,338], () => (__webpack_exec__(2654)));
module.exports = __webpack_exports__;

})();