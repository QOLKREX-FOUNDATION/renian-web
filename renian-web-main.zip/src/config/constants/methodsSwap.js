export const METHODS_MAINET = {
  swapExactTokensForTokens: "swapExactTokensForTokens",
  swapExactNativeCurrencyForTokens: "swapExactNativeCurrencyForTokens",
  swapExactTokensForNativeCurrency: "swapExactTokensForNativeCurrency",
};
export const METHODS_TESNET = {
  swapExactTokensForTokens: "swapExactTokensForTokens",
  swapExactNativeCurrencyForTokens: "swapExactETHForTokens",
  swapExactTokensForNativeCurrency: "swapExactTokensForETH",
};
