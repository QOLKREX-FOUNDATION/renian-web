import DOG from "../../../public/Json/data/selects/race/Dogs.json";
import CAT from "../../../public/Json/data/selects/race/Cats.json";

export const racesJson = {
  DOG,
  CAT,
};
