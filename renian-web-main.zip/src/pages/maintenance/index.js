import { MaintenanceView } from "../../components";

export default function MaintenanceMain() {
  return <MaintenanceView />;
}
