import { FaqView } from "../../components";

export default function FaqMain() {
  return <FaqView />;
}
