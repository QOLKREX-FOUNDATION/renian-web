import { ConsultView } from "../../components";

export default function ConsultMain() {
  return <ConsultView />;
}
