import { CentersView } from "../../components";

export default function CentersMain() {
  return <CentersView />;
}
