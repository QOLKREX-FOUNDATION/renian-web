export const optionsSterilized = [
	{
		value: "NO",
		label: "NO",
	},
	{
		value: "YES",
		label: "SI",
	},
	{
		value: "CASTRATED",
		label: "CASTRADO",
	},
];
