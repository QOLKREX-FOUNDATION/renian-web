export { useChip } from "./useChip";
export { useColours } from "./useColours";
export { useCountry } from "./useCountry";
export { useDocuments } from "./useDocuments";
export { usePerson } from "./usePerson";
export { useSpecie } from "./useSpecies";
export { useType } from "./useType";