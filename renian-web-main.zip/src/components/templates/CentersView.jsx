import { Centers } from "..";

export const CentersView = ({ centers }) => {
	return <Centers centers={centers} />;
};
