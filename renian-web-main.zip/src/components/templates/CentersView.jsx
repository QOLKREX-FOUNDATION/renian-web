import { Centers } from "..";

export const CentersView = () => {
  return <Centers />;
};
