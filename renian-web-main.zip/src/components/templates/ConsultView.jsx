import { Consult, DrawerContainer } from "../";

export const ConsultView = () => {
  return (
    <DrawerContainer>
      <Consult />
    </DrawerContainer>
  );
};
