import { Faq } from "../";

export const FaqView = () => {
  return <Faq />;
};
