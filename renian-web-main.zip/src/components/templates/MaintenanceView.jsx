import { ComingSoon } from "../organisms/ComingSoon/ComingSoon";

export const MaintenanceView = () => {
  return <ComingSoon />;
};
