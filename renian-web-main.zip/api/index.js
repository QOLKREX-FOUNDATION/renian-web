export {default as mailApi} from "./mail";
