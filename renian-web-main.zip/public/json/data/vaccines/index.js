import DOG from "./dogs.json";
import CAT from "./cats.json";

export const SpeciesVaccines = {
	DOG,
	CAT,
};
